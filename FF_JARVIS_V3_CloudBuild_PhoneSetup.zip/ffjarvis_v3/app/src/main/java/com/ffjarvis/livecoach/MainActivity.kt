package com.ffjarvis.livecoach

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
  private val captureRequest = 501
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    val layout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(36,48,36,36); setBackgroundColor(0xFF111827.toInt()) }
    val title = TextView(this).apply { text="FF JARVIS LIVE COACH"; textSize=24f; setTextColor(0xFFFFFFFF.toInt()) }
    val intro = TextView(this).apply { text="Screen OCR + Hindi voice tips (prototype)\n\nTap Start, allow screen capture, then switch to Free Fire." ; textSize=16f; setTextColor(0xFFB8C5D6.toInt()); setPadding(0,24,0,24) }
    val start = Button(this).apply { text="START SCREEN COACH"; setOnClickListener { val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; startActivityForResult(mgr.createScreenCaptureIntent(),captureRequest) } }
    val stop = Button(this).apply { text="STOP COACH"; setOnClickListener { stopService(Intent(this@MainActivity,CaptureCoachService::class.java)) } }
    layout.addView(title); layout.addView(intro); layout.addView(start); layout.addView(stop); setContentView(layout)
  }
  @Deprecated("Use activity result")
  override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==captureRequest && resultCode==RESULT_OK && data!=null){ val i=Intent(this,CaptureCoachService::class.java).putExtra("resultCode",resultCode).putExtra("data",data); startForegroundService(i) } }
}
