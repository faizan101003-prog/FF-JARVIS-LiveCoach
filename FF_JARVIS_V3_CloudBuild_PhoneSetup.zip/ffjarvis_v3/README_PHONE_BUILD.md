# FF JARVIS Live Coach — Cloud APK build (phone-only path)

1. Create/login to GitHub in your phone browser.
2. Create a new repository (name `ff-jarvis-live-coach`, Public or Private).
3. Upload all files/folders in this project into the repository root. Ensure `.github/workflows/build-apk.yml` is included.
4. Commit the upload. GitHub Actions will run automatically.
5. In the repository, open Actions → `Build FF JARVIS APK` → latest run. Wait until green.
6. Open the completed run, scroll to Artifacts, download `FF-JARVIS-APK`, extract it, and tap `app-debug.apk` to install.

Build has not been run/tested in this environment. This is an OCR/rule-based prototype; it does not reliably detect enemies or provide true AI realtime game understanding. It scans about every 2.2 seconds, subject to phone performance. The screen capture consent prompt is required each time you start it.
